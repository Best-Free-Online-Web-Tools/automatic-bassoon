  ****************************************************************************
  **                                                                        **
  **          Diccionario para corrección ortográfica en español de         **
  **                      LibreOffice/Apache OpenOffice                     **
  **                                                                        **
  ****************************************************************************

Para: __LOCALES__

  ****************************************************************************

                                  Versión __VERSION__

SUMARIO

1. AUTOR
2. LICENCIA
3. COLABORACIÓN
4. AGRADECIMIENTOS


1. AUTOR

   Este diccionario ha sido desarrollado inicialmente por Santiago Bosio;
quien actualmente coordina el desarrollo de todos los diccionarios localizados.

   El diccionario es un desarrollo completamente nuevo, y NO ESTÁ BASADO en el
trabajo de Jesús Carretero y Santiago Rodríguez, ni en la versión adaptada al
formato de MySpell por Richard Holt.

2. LICENCIA

   Este diccionario para corrección ortográfica, integrado por el fichero
de afijos y la lista de palabras (__LOCALE__[.aff|.dic]) se distribuye
bajo un triple esquema de licencias disjuntas: GNU GPL versión 3 o posterior,
GNU LGPL versión 3 o posterior, ó MPL versión 1.1 o posterior. Puede
seleccionar libremente bajo cuál de estas licencias utilizará este diccionario.
En el fichero LICENSE.md encontrá más detalles.

3. COLABORACIÓN

   Este diccionario es resultado del trabajo colaborativo de muchas personas.
La buena noticia es que ¡usted también puede participar!

   ¿Tiene dudas o sugerencias? ¿Desearía ver palabras agregadas, o que se
realizaran correcciones? Consulte las indicaciones técnicas publicadas en
CONTRIBUTING.md. Estaremos encantados de atenderle.

4. AGRADECIMIENTOS

   Hay varias personas que han colaborado con aportes o sugerencias a la
creación de este diccionario. Se agradece especialmente a:

   - Richard Holt.
   - Marcelo Garrone.
   - Kevin Hendricks.
   - Juan Rey Saura.
   - Carlos Dávila.
   - Román Gelbort.
   - J. Eduardo Moreno.
   - Gonzalo Higuera Díaz.
   - Ricardo Palomares Martínez.
   - Sergio Medina.
   - Ismael Olea.
   - Alejandro Moreno.
   - Alexandro Colorado.
   - Andrés Sánchez.
   - Juan Rafael Fernández García.
   - eksperimental.
   - Ezequiel (ezeperez26).
   - KNTRO.
   - Ricardo Berlasso.
   - Edward Villegas-Pulgarin (cosmocalibur)
   - y a todos los integrantes de la comunidad en español que proponen mejoras
     a este diccionario.
